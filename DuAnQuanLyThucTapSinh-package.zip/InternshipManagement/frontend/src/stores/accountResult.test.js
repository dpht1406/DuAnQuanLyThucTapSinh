import { beforeEach, describe, expect, it } from 'vitest'
import { createPinia, setActivePinia } from 'pinia'
import { useAccountResultStore } from './accountResult.js'

describe('accountResult store', () => {
  beforeEach(() => {
    setActivePinia(createPinia())
  })

  it('starts with empty state', () => {
    const store = useAccountResultStore()
    expect(store.kind).toBeNull()
    expect(store.payload).toBeNull()
  })

  it('sets kind and payload for company', () => {
    const store = useAccountResultStore()
    store.set('company', { username: 'cty_abc', temporaryPassword: 'pwd', mode: 'create' })
    expect(store.kind).toBe('company')
    expect(store.payload).toEqual({ username: 'cty_abc', temporaryPassword: 'pwd', mode: 'create' })
  })

  it('clears state', () => {
    const store = useAccountResultStore()
    store.set('student-reset', { studentCode: 'SV001', temporaryPassword: 'pwd' })
    expect(store.kind).toBe('student-reset')
    store.clear()
    expect(store.kind).toBeNull()
    expect(store.payload).toBeNull()
  })
})
