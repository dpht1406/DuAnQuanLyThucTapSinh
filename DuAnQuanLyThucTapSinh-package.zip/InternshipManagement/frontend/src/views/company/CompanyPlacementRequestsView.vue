<script setup>
import { computed, onMounted, reactive, ref } from 'vue'
import Button from 'primevue/button'
import Column from 'primevue/column'
import DataTable from 'primevue/datatable'
import Dialog from 'primevue/dialog'
import Drawer from 'primevue/drawer'
import InputText from 'primevue/inputtext'
import Message from 'primevue/message'
import Paginator from 'primevue/paginator'
import Select from 'primevue/select'
import Tag from 'primevue/tag'
import Textarea from 'primevue/textarea'
import { useConfirm } from 'primevue/useconfirm'
import { useToast } from 'primevue/usetoast'
import {
  getCompanyPlacementRequestById,
  getCompanyPlacementRequests,
  inviteCompanyPlacementRequestToInterview,
  recordCompanyPlacementResult,
  rejectCompanyPlacementRequest
} from '../../api/company-me.js'
import { extractErrorMessage } from '../../utils/apiError.js'
import { formatServerDateTime } from '../../utils/dateTime.js'
import {
  mapPlacementRequestDueStatus,
  mapPlacementRequestStatus,
  PLACEMENT_REQUEST_STATUSES,
  validateCompanyInterviewForm,
  validateCompanyPlacementResult,
  validateCompanyRejectReason
} from '../../utils/companyPlacementRequest.js'

const confirm = useConfirm()
const toast = useToast()
const requests = ref([])
const totalRecords = ref(0)
const pageNumber = ref(1)
const pageSize = ref(10)
const statusFilter = ref(null)
const loading = ref(false)
const error = ref('')
const selectedId = ref(null)
const drawerVisible = ref(false)
const detail = ref(null)
const detailLoading = ref(false)
const detailError = ref('')
const actionDialog = ref('')
const sending = ref(false)
const actionError = ref('')
const fieldErrors = ref({})
const interviewForm = reactive({ interviewAt: '', interviewLocation: '', interviewNote: '' })
const rejectReason = ref('')
const resultNote = ref('')

const statusOptions = [
  { label: 'Tất cả trạng thái', value: null },
  ...PLACEMENT_REQUEST_STATUSES.map(({ label, value }) => ({ label, value }))
]
const drawerHeader = computed(() => detail.value
  ? `Đơn ứng tuyển #${detail.value.id}`
  : 'Chi tiết đơn ứng tuyển')
const canRespond = computed(() => mapPlacementRequestStatus(detail.value?.status).value === 0)
const canRecordResult = computed(() => mapPlacementRequestStatus(detail.value?.status).value === 3)

function statusOf(request) {
  return mapPlacementRequestStatus(request?.status)
}

function dueOf(request) {
  return mapPlacementRequestDueStatus(request?.dueAt)
}

function applicantName(request) {
  return request?.applicantFullName || request?.studentFullName || '—'
}

function dateLabel(value) {
  return formatServerDateTime(value) ?? '—'
}

function dueLabel(request) {
  const dueStatus = dueOf(request)
  if (dueStatus === 'overdue') return 'Đã quá hạn'
  if (dueStatus === 'soon') return 'Sắp đến hạn'
  return dateLabel(request.dueAt)
}

async function loadRequests() {
  loading.value = true
  error.value = ''
  try {
    const result = await getCompanyPlacementRequests({
      status: statusFilter.value,
      pageNumber: pageNumber.value,
      pageSize: pageSize.value
    })
    requests.value = result?.items ?? []
    totalRecords.value = result?.totalCount ?? 0
  } catch (err) {
    error.value = extractErrorMessage(err, 'Không tải được danh sách đơn ứng tuyển.')
    requests.value = []
    totalRecords.value = 0
  } finally {
    loading.value = false
  }
}

async function loadDetail(id) {
  detailLoading.value = true
  detailError.value = ''
  try {
    detail.value = await getCompanyPlacementRequestById(id)
  } catch (err) {
    detailError.value = extractErrorMessage(err, 'Không tải được chi tiết đơn ứng tuyển.')
    detail.value = null
  } finally {
    detailLoading.value = false
  }
}

async function openDetail(request) {
  selectedId.value = request.id
  drawerVisible.value = true
  detail.value = null
  detailError.value = ''
  await loadDetail(request.id)
}

function closeDrawer() {
  if (sending.value) return
  selectedId.value = null
  drawerVisible.value = false
  detail.value = null
  detailError.value = ''
}

function onStatusChange() {
  pageNumber.value = 1
  loadRequests()
}

function onPage(event) {
  pageNumber.value = event.page + 1
  pageSize.value = event.rows
  loadRequests()
}

function notifySuccess(detailMessage) {
  toast.add({ severity: 'success', summary: 'Thành công', detail: detailMessage, life: 3000 })
}

function openAction(kind) {
  actionError.value = ''
  fieldErrors.value = {}
  actionDialog.value = kind
  if (kind === 'interview') {
    const defaultDate = new Date(Date.now() + 24 * 60 * 60 * 1000)
    const localDate = new Date(defaultDate.getTime() - defaultDate.getTimezoneOffset() * 60000)
    interviewForm.interviewAt = localDate.toISOString().slice(0, 16)
    interviewForm.interviewLocation = ''
    interviewForm.interviewNote = ''
  } else if (kind === 'reject') {
    rejectReason.value = ''
  } else if (kind === 'result') {
    resultNote.value = ''
  }
}

function closeActionDialog() {
  if (!sending.value) actionDialog.value = ''
}

async function refreshAfterConflict() {
  await loadRequests()
  if (selectedId.value !== null) await loadDetail(selectedId.value)
  error.value = 'Dữ liệu vừa thay đổi'
}

async function setActionError(err, fallback) {
  if (err?.response?.status === 409) {
    await refreshAfterConflict()
    return 'Dữ liệu vừa thay đổi'
  }
  return extractErrorMessage(err, fallback)
}

async function completeAction(successMessage) {
  actionDialog.value = ''
  notifySuccess(successMessage)
  await loadRequests()
  if (selectedId.value !== null) await loadDetail(selectedId.value)
}

async function submitInterview() {
  if (sending.value) return
  fieldErrors.value = validateCompanyInterviewForm(interviewForm)
  if (Object.keys(fieldErrors.value).length) return

  sending.value = true
  actionError.value = ''
  try {
    await inviteCompanyPlacementRequestToInterview(detail.value.id, {
      interviewAt: new Date(interviewForm.interviewAt).toISOString(),
      interviewLocation: interviewForm.interviewLocation.trim(),
      interviewNote: interviewForm.interviewNote.trim() || null
    })
    await completeAction('Đã gửi lời mời phỏng vấn.')
  } catch (err) {
    actionError.value = await setActionError(err, 'Không thể gửi lời mời phỏng vấn.')
  } finally {
    sending.value = false
  }
}

async function submitRejection() {
  if (sending.value) return
  const reasonError = validateCompanyRejectReason(rejectReason.value)
  fieldErrors.value = reasonError ? { reason: reasonError } : {}
  if (reasonError) return

  sending.value = true
  actionError.value = ''
  try {
    await rejectCompanyPlacementRequest(detail.value.id, { reason: rejectReason.value.trim() })
    await completeAction('Đã từ chối đơn ứng tuyển.')
  } catch (err) {
    actionError.value = await setActionError(err, 'Không thể từ chối đơn ứng tuyển.')
  } finally {
    sending.value = false
  }
}

function confirmResult(isPassed) {
  if (sending.value) return
  const resultError = validateCompanyPlacementResult(isPassed, resultNote.value)
  fieldErrors.value = resultError ? { resultNote: resultError } : {}
  if (resultError) return

  const outcome = isPassed ? 'Đạt' : 'Không đạt'
  confirm.require({
    message: `Xác nhận ghi nhận kết quả ${outcome} cho ${applicantName(detail.value)}?`,
    header: `Xác nhận kết quả ${outcome}`,
    icon: 'pi pi-exclamation-triangle',
    rejectLabel: 'Hủy',
    acceptLabel: 'Xác nhận',
    rejectClass: 'p-button-secondary p-button-text',
    acceptClass: isPassed ? 'p-button-success' : 'p-button-danger',
    accept: () => submitResult(isPassed)
  })
}

async function submitResult(isPassed) {
  if (sending.value) return
  sending.value = true
  actionError.value = ''
  try {
    await recordCompanyPlacementResult(detail.value.id, {
      isPassed,
      note: resultNote.value.trim() || null
    })
    await completeAction(`Đã ghi nhận kết quả ${isPassed ? 'Đạt' : 'Không đạt'}.`)
  } catch (err) {
    actionError.value = await setActionError(err, 'Không thể ghi nhận kết quả đơn ứng tuyển.')
  } finally {
    sending.value = false
  }
}

onMounted(loadRequests)
</script>

<template>
  <div class="page-container company-placement-requests">
    <header class="requests-heading">
      <div>
        <h1 class="page-title">Đơn ứng tuyển</h1>
        <p class="requests-subtitle">Theo dõi hồ sơ, phản hồi ứng viên và ghi nhận kết quả phỏng vấn.</p>
      </div>
      <div class="status-filter">
        <label for="placement-request-status">Trạng thái</label>
        <Select
          id="placement-request-status"
          v-model="statusFilter"
          :options="statusOptions"
          option-label="label"
          option-value="value"
          aria-label="Lọc theo trạng thái đơn ứng tuyển"
          @change="onStatusChange"
        />
      </div>
    </header>

    <Message v-if="error" severity="error" :closable="false">{{ error }}</Message>

    <DataTable
      :value="requests"
      :lazy="true"
      :paginator="true"
      :rows="pageSize"
      :total-records="totalRecords"
      :first="(pageNumber - 1) * pageSize"
      :rows-per-page-options="[10, 20, 50]"
      :loading="loading"
      data-key="id"
      class="company-placement-table"
      @page="onPage"
    >
      <Column header="Ứng viên">
        <template #body="{ data }">
          <div class="applicant-cell">
            <strong>{{ applicantName(data) }}</strong>
            <small>{{ data.applicantEmail || 'Chưa có email' }}</small>
          </div>
        </template>
      </Column>
      <Column header="Vị trí">
        <template #body="{ data }">{{ data.jobPositionTitle || 'Ứng tuyển chung' }}</template>
      </Column>
      <Column header="Ngày gửi">
        <template #body="{ data }">{{ dateLabel(data.createdAt) }}</template>
      </Column>
      <Column header="Hạn phản hồi">
        <template #body="{ data }">
          <div class="due-cell" :class="`due-${dueOf(data)}`">
            <strong v-if="dueOf(data) !== 'normal' && dueOf(data) !== 'none'">{{ dueLabel(data) }}</strong>
            <span>{{ dateLabel(data.dueAt) }}</span>
          </div>
        </template>
      </Column>
      <Column header="Trạng thái">
        <template #body="{ data }">
          <Tag :value="statusOf(data).label" :severity="statusOf(data).severity" />
        </template>
      </Column>
      <Column header="Chi tiết">
        <template #body="{ data }">
          <Button label="Xem đơn" icon="pi pi-eye" size="small" text @click="openDetail(data)" />
        </template>
      </Column>
      <template #empty>Chưa có đơn ứng tuyển phù hợp.</template>
    </DataTable>

    <section class="mobile-request-list" aria-label="Danh sách đơn ứng tuyển">
      <article v-for="request in requests" :key="request.id" class="mobile-request-card">
        <div class="mobile-request-top">
          <div class="applicant-cell">
            <strong>{{ applicantName(request) }}</strong>
            <small>{{ request.applicantEmail || 'Chưa có email' }}</small>
          </div>
          <Tag :value="statusOf(request).label" :severity="statusOf(request).severity" />
        </div>
        <p>{{ request.jobPositionTitle || 'Ứng tuyển chung' }}</p>
        <div class="mobile-request-meta">
          <span>Ngày gửi: {{ dateLabel(request.createdAt) }}</span>
          <span :class="`due-${dueOf(request)}`">Hạn: {{ dueLabel(request) }}</span>
        </div>
        <Button label="Xem đơn" icon="pi pi-eye" size="small" outlined @click="openDetail(request)" />
      </article>
      <p v-if="!loading && requests.length === 0" class="empty-state">Chưa có đơn ứng tuyển phù hợp.</p>
      <Paginator
        v-if="totalRecords > pageSize"
        :first="(pageNumber - 1) * pageSize"
        :rows="pageSize"
        :total-records="totalRecords"
        :rows-per-page-options="[10, 20, 50]"
        @page="onPage"
      />
    </section>

    <Drawer
      v-model:visible="drawerVisible"
      position="right"
      class="placement-request-drawer"
      :header="drawerHeader"
      :style="{ width: 'min(42rem, 100vw)' }"
      @update:visible="(visible) => { if (!visible) closeDrawer() }"
    >
      <div v-if="detailLoading" class="drawer-message">Đang tải chi tiết đơn...</div>
      <Message v-else-if="detailError" severity="error" :closable="false">{{ detailError }}</Message>
      <template v-else-if="detail">
        <div class="detail-header">
          <Tag :value="statusOf(detail).label" :severity="statusOf(detail).severity" />
          <span :class="`due-${mapPlacementRequestDueStatus(detail.dueAt)}`">
            Hạn phản hồi: {{ dueLabel(detail) }}
          </span>
        </div>

        <section class="detail-section">
          <h2>Thông tin ứng viên</h2>
          <dl class="applicant-details">
            <div><dt>Họ tên</dt><dd>{{ applicantName(detail) }}</dd></div>
            <div><dt>Email</dt><dd>{{ detail.applicantEmail || '—' }}</dd></div>
            <div><dt>Số điện thoại</dt><dd>{{ detail.applicantPhone || '—' }}</dd></div>
            <div><dt>Trường</dt><dd>{{ detail.applicantSchool || '—' }}</dd></div>
            <div><dt>Ngành</dt><dd>{{ detail.applicantMajor || detail.major || '—' }}</dd></div>
            <div><dt>Lớp</dt><dd>{{ detail.className || '—' }}</dd></div>
            <div><dt>Vị trí ứng tuyển</dt><dd>{{ detail.jobPositionTitle || 'Ứng tuyển chung' }}</dd></div>
            <div>
              <dt>CV</dt>
              <dd>
                <a
                  v-if="detail.cvUrl"
                  :href="detail.cvUrl"
                  target="_blank"
                  rel="noopener noreferrer"
                >Mở CV trong tab mới</a>
                <span v-else>—</span>
              </dd>
            </div>
          </dl>
          <div class="letter-block">
            <h3>Thư giới thiệu</h3>
            <p>{{ detail.coverLetter || detail.note || 'Ứng viên không gửi thư giới thiệu.' }}</p>
          </div>
        </section>

        <section v-if="detail.interviewAt || detail.rejectReason || detail.resultNote" class="detail-section">
          <h2>Thông tin xử lý</h2>
          <dl class="applicant-details">
            <div v-if="detail.interviewAt"><dt>Lịch phỏng vấn</dt><dd>{{ dateLabel(detail.interviewAt) }}</dd></div>
            <div v-if="detail.interviewLocation"><dt>Địa điểm</dt><dd>{{ detail.interviewLocation }}</dd></div>
            <div v-if="detail.interviewNote"><dt>Ghi chú phỏng vấn</dt><dd>{{ detail.interviewNote }}</dd></div>
            <div v-if="detail.rejectReason"><dt>Lý do từ chối</dt><dd>{{ detail.rejectReason }}</dd></div>
            <div v-if="detail.resultNote"><dt>Ghi chú kết quả</dt><dd>{{ detail.resultNote }}</dd></div>
          </dl>
        </section>

        <Message v-if="actionError" severity="error" :closable="false">{{ actionError }}</Message>

        <section v-if="canRespond" class="detail-actions">
          <h2>Phản hồi đơn</h2>
          <div class="action-buttons">
            <Button label="Mời phỏng vấn" icon="pi pi-calendar-plus" :disabled="sending" @click="openAction('interview')" />
            <Button label="Từ chối" icon="pi pi-times" severity="danger" outlined :disabled="sending" @click="openAction('reject')" />
          </div>
        </section>
        <section v-else-if="canRecordResult" class="detail-actions">
          <h2>Ghi kết quả phỏng vấn</h2>
          <label for="placement-result-note">Ghi chú <span v-if="resultNote.length === 0">(bắt buộc nếu Không đạt)</span></label>
          <Textarea
            id="placement-result-note"
            v-model="resultNote"
            rows="3"
            :maxlength="1001"
            :disabled="sending"
            aria-describedby="placement-result-error"
          />
          <small v-if="fieldErrors.resultNote" id="placement-result-error" class="field-error">{{ fieldErrors.resultNote }}</small>
          <div class="action-buttons">
            <Button label="Đạt" icon="pi pi-check" severity="success" :disabled="sending" @click="confirmResult(true)" />
            <Button label="Không đạt" icon="pi pi-times" severity="danger" outlined :disabled="sending" @click="confirmResult(false)" />
          </div>
        </section>
      </template>
    </Drawer>

    <Dialog
      :visible="Boolean(actionDialog)"
      modal
      :header="actionDialog === 'interview' ? 'Mời phỏng vấn' : 'Từ chối đơn ứng tuyển'"
      :style="{ width: 'min(34rem, calc(100vw - 2rem))' }"
      :closable="!sending"
      @update:visible="(visible) => { if (!visible) closeActionDialog() }"
    >
      <Message v-if="actionError" severity="error" :closable="false">{{ actionError }}</Message>
      <form v-if="actionDialog === 'interview'" class="action-form" novalidate @submit.prevent="submitInterview">
        <label for="interview-at">Ngày giờ phỏng vấn</label>
        <InputText id="interview-at" v-model="interviewForm.interviewAt" type="datetime-local" :disabled="sending" />
        <small v-if="fieldErrors.interviewAt" class="field-error">{{ fieldErrors.interviewAt }}</small>
        <label for="interview-location">Địa điểm</label>
        <InputText id="interview-location" v-model="interviewForm.interviewLocation" maxlength="501" :disabled="sending" />
        <small v-if="fieldErrors.interviewLocation" class="field-error">{{ fieldErrors.interviewLocation }}</small>
        <label for="interview-note">Ghi chú <span>(tùy chọn)</span></label>
        <Textarea id="interview-note" v-model="interviewForm.interviewNote" rows="3" maxlength="1001" :disabled="sending" />
        <small v-if="fieldErrors.interviewNote" class="field-error">{{ fieldErrors.interviewNote }}</small>
        <div class="dialog-actions">
          <Button type="button" label="Hủy" severity="secondary" text :disabled="sending" @click="closeActionDialog" />
          <Button type="submit" label="Gửi lời mời" icon="pi pi-send" :loading="sending" :disabled="sending" />
        </div>
      </form>
      <form v-else class="action-form" novalidate @submit.prevent="submitRejection">
        <label for="reject-reason">Lý do từ chối</label>
        <Textarea id="reject-reason" v-model="rejectReason" rows="4" maxlength="1001" :disabled="sending" />
        <small v-if="fieldErrors.reason" class="field-error">{{ fieldErrors.reason }}</small>
        <div class="dialog-actions">
          <Button type="button" label="Hủy" severity="secondary" text :disabled="sending" @click="closeActionDialog" />
          <Button type="submit" label="Từ chối đơn" icon="pi pi-times" severity="danger" :loading="sending" :disabled="sending" />
        </div>
      </form>
    </Dialog>
  </div>
</template>

<style scoped>
.company-placement-requests { display: grid; gap: 18px; }
.requests-heading { display: flex; align-items: end; justify-content: space-between; gap: 18px; }
.requests-subtitle { margin: 7px 0 0; color: var(--text); font-size: 14px; }
.status-filter { display: grid; min-width: 220px; gap: 6px; }
.status-filter label, .detail-actions > label { color: var(--text-h); font-size: 13px; font-weight: 600; }
.company-placement-table { border: 1px solid var(--border); border-radius: 12px; overflow: hidden; }
.applicant-cell { display: grid; min-width: 0; gap: 4px; }
.applicant-cell strong { color: var(--text-h); }
.applicant-cell small { color: var(--text); overflow-wrap: anywhere; }
.due-cell { display: grid; gap: 3px; white-space: nowrap; }
.due-cell span { color: var(--text); font-size: 12px; }
.due-overdue { color: var(--danger); font-weight: 600; }
.due-soon { color: #a15c00; font-weight: 600; }
.due-normal, .due-none { color: var(--text); }
.mobile-request-list { display: none; }
.placement-request-drawer { max-width: 100vw; }
.drawer-message { color: var(--text); }
.detail-header { display: flex; align-items: center; justify-content: space-between; gap: 12px; padding-bottom: 18px; border-bottom: 1px solid var(--border); }
.detail-section, .detail-actions { display: grid; gap: 14px; margin-top: 22px; }
.detail-section h2, .detail-actions h2 { margin: 0; color: var(--text-h); font-size: 17px; }
.applicant-details { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 16px 20px; margin: 0; }
.applicant-details > div { min-width: 0; }
.applicant-details dt { margin-bottom: 4px; color: var(--text); font-size: 12px; }
.applicant-details dd { margin: 0; color: var(--text-h); font-size: 14px; overflow-wrap: anywhere; }
.applicant-details a { color: var(--primary); }
.letter-block { padding: 14px; background: var(--surface-soft); border-radius: 10px; }
.letter-block h3 { margin: 0 0 8px; color: var(--text-h); font-size: 14px; }
.letter-block p { margin: 0; color: var(--text); line-height: 1.55; white-space: pre-wrap; overflow-wrap: anywhere; }
.action-buttons, .dialog-actions { display: flex; flex-wrap: wrap; gap: 10px; }
.detail-actions { padding-top: 18px; border-top: 1px solid var(--border); }
.detail-actions textarea { width: 100%; }
.action-form { display: grid; gap: 8px; }
.action-form label { margin-top: 4px; color: var(--text-h); font-size: 13px; font-weight: 600; }
.action-form label span, .detail-actions label span { color: var(--text); font-weight: 400; }
.action-form :deep(.p-inputtext), .action-form :deep(.p-textarea) { width: 100%; }
.field-error { color: var(--danger); font-size: 12px; }
.dialog-actions { justify-content: flex-end; margin-top: 10px; }
.empty-state { color: var(--text); text-align: center; }
@media (max-width: 767px) {
  .company-placement-requests { gap: 14px; }
  .requests-heading { align-items: stretch; flex-direction: column; }
  .status-filter { min-width: 0; }
  .company-placement-table { display: none; }
  .mobile-request-list { display: grid; gap: 12px; }
  .mobile-request-card { display: grid; gap: 12px; padding: 16px; background: var(--surface); border: 1px solid var(--border); border-radius: 12px; }
  .mobile-request-top { display: flex; align-items: flex-start; justify-content: space-between; gap: 10px; }
  .mobile-request-card > p { margin: 0; color: var(--text-h); font-size: 14px; }
  .mobile-request-meta { display: grid; gap: 6px; color: var(--text); font-size: 12px; }
  .mobile-request-card :deep(.p-button) { min-height: 42px; }
  .applicant-details { grid-template-columns: 1fr; gap: 13px; }
  .action-buttons :deep(.p-button) { flex: 1 1 100%; min-height: 44px; }
  .dialog-actions { flex-direction: column-reverse; }
  .dialog-actions :deep(.p-button) { width: 100%; min-height: 44px; }
}
</style>
