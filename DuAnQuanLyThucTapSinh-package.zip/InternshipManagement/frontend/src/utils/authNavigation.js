export function getPasswordChangeRedirect(isAuthenticated, mustChangePassword, path) {
  if (
    isAuthenticated &&
    mustChangePassword &&
    path !== '/login' &&
    path !== '/change-password'
  ) {
    return '/change-password'
  }

  return null
}

export function getSafeReturnPath(raw) {
  const path = typeof raw === 'string' ? raw.split(/[?#]/, 1)[0] : ''

  if (
    typeof raw === 'string' &&
    raw.startsWith('/') &&
    !raw.startsWith('//') &&
    path !== '/change-password' &&
    path !== '/login'
  ) {
    return raw
  }

  return '/'
}
