namespace StudentInternshipMgmt.Domain.Enums;

public enum AdminPlacementDecision
{
    Passed,
    Failed,
    DismissReport
}

public enum PlacementResultDecision
{
    Passed,
    Failed,
    DismissReport
}

public enum InterviewConfirmationDecision
{
    Passed,
    Failed,
    DismissReport
}
